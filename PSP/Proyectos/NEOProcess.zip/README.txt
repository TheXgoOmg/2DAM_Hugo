# SO
- Ha sido probado en el SO Windows 11.

# Tiempo medio de ejecución
- El tiempo medio de ejecución del programa es de unos 30 segundos aproximadamente.
- Y el tiempo medio de cada proceso es de unos 27 segundos.

# Obstáculos
- He encontrado obstáculos al encontrar la lógica de que se ejecuten de manera paralela cada cálculo.
  Y Enrique me iluminó con su idea en un sola frase "Ejecuta un archivo externo". Así que lo he hecho
  creando procesos de un archivo que calcula la probabilidad de colisión con la Tierra a partir de la
  información de cada NEO.
- También tuve problemas al tratar de sacar el tiempo de ejecución de cada proceso para sacar la
  media. Opté por imprimirlo por la consola, además de capturarlo y añadirlo a una List para sacar la
  media al final de la ejecución del programa.

# Limitaciones
- Creo que solo tiene las básicas por no incorporar la funcionalidad de la versiones 2 y 3 de NEO
  analizar, ya que solo puede calcular la probabilidad de colisión de la cantidad de NEOs como sea la
  cantidad de cores del procesador.