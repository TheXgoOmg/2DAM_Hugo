import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

class Cliente {
    static final String Host = "localhost";
    static final int Puerto = 2000;

    public Cliente() {

        try {
            Socket sCliente = new Socket(Host, Puerto);
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(sCliente.getInputStream(), StandardCharsets.UTF_8));
            PrintWriter out = new PrintWriter(
                    new OutputStreamWriter(sCliente.getOutputStream(), StandardCharsets.UTF_8),
                    true // autoFlush en println
            );

            System.out.println("Conexión iniciada");
            System.out.println("Puerto local : " + sCliente.getLocalPort());
            System.out.println("Puerto remoto : " + sCliente.getPort());
            System.out.println("Dirección remota : " + sCliente.getInetAddress());

            // 1) Leer saludo del servidor
            Scanner sc = new Scanner(System.in);
            String msgServidor = in.readLine();
            if (msgServidor != null) {
                System.out.println("Mensaje del servidor: " + msgServidor);
            } else {
                System.out.println("Mensaje del servidor: <nada recibido>");
            }

            // 2) Pedir mensaje al usuario y enviarlo
            System.out.print("Escribe un mensaje para enviar al servidor: ");
            String mensajeUsuario = sc.nextLine();

            out.println(mensajeUsuario); // añade salto y hace flush automáticamente

            System.out.println("Conexión cerrada");
            out.close();
            in.close();
            sCliente.close();
        } catch (Exception e) {
            System.out.println("Error en cliente: " + e.getMessage());
        }
    }

    public static void main(String[] arg) {
        new Cliente();
    }
}