
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

class Servidor {
    static final int Puerto = 2000;

    public Servidor() {
        try (ServerSocket skServidor = new ServerSocket(Puerto)) {
            System.out.println("Escuchando el puerto " + Puerto);

            for (int nCli = 1; nCli <= 3; nCli++) {
                try (
                        Socket sCliente = skServidor.accept();
                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(sCliente.getInputStream(), StandardCharsets.UTF_8));
                        PrintWriter out = new PrintWriter(
                                new OutputStreamWriter(sCliente.getOutputStream(), StandardCharsets.UTF_8),
                                true // autoFlush al usar println/printf/format
                        )
                ) {
                    System.out.println("Conexión recibida de cliente " + nCli);
                    System.out.println("Puerto local : " + sCliente.getLocalPort());
                    System.out.println("Puerto remoto : " + sCliente.getPort());
                    System.out.println("Dirección remota : " + sCliente.getInetAddress());

                    // 1) Enviar saludo
                    out.println("Hola cliente " + nCli); // añade salto y hace flush

                    // 2) Leer mensaje del cliente
                    String msgCliente = in.readLine(); // bloquea hasta recibir línea o cierre
                    if (msgCliente != null) {
                        System.out.println("Mensaje del cliente : " + msgCliente);
                    } else {
                        System.out.println("Mensaje del cliente : <conexión cerrada sin datos>");
                    }
                } catch (Exception eCliente) {
                    System.out.println("Error con cliente " + nCli + ": " + eCliente.getMessage());
                }
            }

            System.out.println("Servidor: fin de servicio (3 clientes atendidos).");
        } catch (Exception e) {
            System.out.println("Error en servidor: " + e.getMessage());
        }
    }

    public static void main(String[] arg) {
        new Servidor();
    }
}
