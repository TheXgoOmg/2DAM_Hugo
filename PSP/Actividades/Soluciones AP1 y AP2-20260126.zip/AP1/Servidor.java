import java.io.* ;
import java.net.* ;

class Servidor {
    static final int Puerto = 2000;
    public Servidor( ) {
        try {
            // Inicio la escucha del servidor en un determinado puerto
            ServerSocket skServidor = new ServerSocket(Puerto);
            System.out.println("Escuchando el puerto " + Puerto );
            for (int nCli = 1; nCli <= 3; nCli++) {
                Socket sCliente = skServidor.accept();
                System.out.println("Conexión recibida de cliente " + nCli);
                System.out.println("Puerto local : " + sCliente.getLocalPort());
                System.out.println("Puerto remoto : " + sCliente.getPort());
                System.out.println("Dirección remota : " + sCliente.getInetAddress());
                sCliente.close();
            }
            skServidor.close();
            System.out.println("Conexión cerrada");
        } catch( Exception e ) {
            System.out.println( e.getMessage() );
        }
    }
    public static void main( String[] arg ) {
        new Servidor();
    }
}