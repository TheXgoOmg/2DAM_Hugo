import java.net.Socket;

class Cliente {
    static final String Host = "localhost";
    static final int Puerto = 2000;

    public Cliente() {
        try {
            // Me conecto al servidor en un determinado puerto
            Socket sCliente = new Socket(Host, Puerto);
            System.out.println("Conexión iniciada");
            // TAREAS QUE REALIZA EL CLIENTE
            System.out.println("Puerto local : " + sCliente.getLocalPort());
            System.out.println("Puerto remoto : " + sCliente.getPort());
            System.out.println("Dirección remota : " + sCliente.getInetAddress());
            // Cierro el socket
            sCliente.close();
            System.out.println("Conexión cerrada");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] arg) {
        new Cliente();
    }
}