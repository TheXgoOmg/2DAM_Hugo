import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;

public class Main {
    final static byte[] BMP_MAGIC_VALUE = {0x42, 0x4D};

    final static byte[] PNG_MAGIC_VALUE = { -0x77, 'P', 'N', 'G', '\r', '\n', 0x1A, '\n'};
    final static byte[] IHDR = {'I', 'H', 'D', 'R'};
    final static byte[] IEND = {'I', 'E', 'N', 'D'};

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Argumentos incorrectos");
            return;
        }

        String ruta = args[0];

        byte[] tipo = new byte[4];
        try (DataInputStream dis = new DataInputStream(new FileInputStream(ruta))) {
            byte[] boff = new byte[8];
            dis.readFully(boff, 0, 2);
            if (Arrays.equals(BMP_MAGIC_VALUE, 0, 2, boff, 0, 2)) {
                dis.skip(16);
                System.out.println("Soy BMP");
                System.out.println("Anchura: " + Integer.reverseBytes(dis.readInt()));
                System.out.println("Altura: " + Integer.reverseBytes(dis.readInt()));
            } else if (Arrays.equals(PNG_MAGIC_VALUE, 0, 2, boff, 0, 2)) {
                dis.readFully(boff, 2, 6);
                if (Arrays.equals(PNG_MAGIC_VALUE, boff)) {
                    do {
                        int longitud = dis.readInt();
                        dis.readFully(tipo);

                        if (Arrays.equals(tipo, IHDR)) {
                            System.out.println("Soy PNG");
                            System.out.println("Anchura: " + dis.readInt());
                            System.out.println("Altura: " + dis.readInt());
                            return;
                        } else {
                            dis.skip(longitud);
                        }

                        dis.skip(4);
                    } while (!Arrays.equals(tipo, IEND));
                }
            }
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}